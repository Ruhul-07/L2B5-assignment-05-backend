import bcryptjs from "bcryptjs";
import AppError from "../../errorHelpers/appError";
import httpStatus from "http-status-codes";
import { User } from "./user.model";
import { envVars } from "../../config/env";
import { IUser } from "../../types";

const createUser = async (payload: Partial<IUser>) => {
    const { phone, password, ...rest } = payload;

    const isUserExist = await User.findOne({ phone })

    if (isUserExist) {
        throw new AppError(httpStatus.BAD_REQUEST, "User Already Exist")
    }

    const hashedPassword = await bcryptjs.hash(password as string, Number(envVars.BCRYPT_SALT_ROUND))


    const user = await User.create({
        phone,
        password: hashedPassword,
        ...rest
    })

    return user

}

const getAllUsers = async () => {
    const users = await User.find({});
    const totalUsers = await User.countDocuments();
    return {
        data: users,
        meta: {
            total: totalUsers
        }
    }
};

export const UserServices = {
    createUser,
    getAllUsers
}