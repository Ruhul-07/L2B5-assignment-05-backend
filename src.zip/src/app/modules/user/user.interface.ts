export interface IUpdateProfileRequest {
  name?: string
  phone?: string
}

export interface IChangePasswordRequest {
  currentPassword: string
  newPassword: string
}

export interface IUserProfileResponse {
  user: {
    _id: string
    name: string
    email: string
    phone: string
    role: string
    isActive: boolean
    isApproved: boolean
    createdAt: Date
    updatedAt: Date
  }
  wallet: {
    balance: number
    isBlocked: boolean
  } | null
}
